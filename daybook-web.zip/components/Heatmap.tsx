'use client';

import { Task, TaskCompletion } from '@/lib/types';
import { computeDayStatus, toDateKey } from '@/lib/dates';

interface HeatmapProps {
  tasks: Task[];
  completions: TaskCompletion[];
  weeksBack?: number;
}

export default function Heatmap({ tasks, completions, weeksBack = 17 }: HeatmapProps) {
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const completedKeys = new Set(
    completions.filter((c) => c.completed).map((c) => `${c.task_id}_${c.date}`)
  );

  // Extend the range to end on the upcoming Saturday so full weeks line up as columns
  const endDate = new Date(today);
  endDate.setDate(endDate.getDate() + (6 - endDate.getDay()));

  const totalDays = weeksBack * 7;
  const startDate = new Date(endDate);
  startDate.setDate(startDate.getDate() - totalDays + 1);

  const days: Date[] = [];
  for (let i = 0; i < totalDays; i++) {
    const d = new Date(startDate);
    d.setDate(startDate.getDate() + i);
    days.push(d);
  }

  const colorClass: Record<string, string> = {
    green: 'bg-emerald-600',
    red: 'bg-rose-600',
    empty: 'bg-line/40',
  };

  if (tasks.length === 0) {
    return (
      <p className="text-ink-muted italic text-sm">
        Add a daily, weekly, or monthly task inside a project folder to start tracking it here.
      </p>
    );
  }

  return (
    <div className="overflow-x-auto pb-2">
      <div
        className="grid gap-1"
        style={{ gridTemplateRows: 'repeat(7, 12px)', gridAutoFlow: 'column', width: 'max-content' }}
      >
        {days.map((d) => {
          const status = computeDayStatus(d, tasks, completedKeys, today);
          const label =
            status === 'green' ? 'completed' : status === 'red' ? 'missed' : 'nothing due';
          return (
            <div
              key={toDateKey(d)}
              title={`${toDateKey(d)} — ${label}`}
              className={`w-3 h-3 rounded-sm ${colorClass[status]}`}
            />
          );
        })}
      </div>
    </div>
  );
}
